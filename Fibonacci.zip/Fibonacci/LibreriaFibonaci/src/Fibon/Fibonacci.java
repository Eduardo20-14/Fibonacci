/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fibon;

/**
 *
 * @author angel
 */
public class Fibonacci {
    private int tamaño;
    private String nombre;
    private String fibonacci_1;
    int i;

public Fibonacci(String nombre, int tamaño){
     throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  
}

    /**
     *
     * @param fibonacci_1
     * @param i
     */


public void mostrarSerie(){
    System.out.println(this.nombre+" de tamaño "+this.tamaño+":");
    for (int i = 0; i < tamaño; i++) {
        System.out.print(fibonacci(i)+" ");
    }
    System.out.println();
}
public String getNombre() {
    return nombre;
}

public void setNombre(String nombre) {
    this.nombre = nombre;
}

public int getTamaño() {
    return tamaño;
}

public void setTamaño(int tamaño) {
    this.tamaño = tamaño;
}
Fibonacci f1 = new Fibonacci("fibonacci 1",10); 

    private String fibonacci(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}